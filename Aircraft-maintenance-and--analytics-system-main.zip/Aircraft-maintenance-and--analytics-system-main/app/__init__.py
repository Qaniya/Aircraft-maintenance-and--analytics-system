"""
Flask application factory
"""
import contextlib
import os
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_login import LoginManager

db = SQLAlchemy()
jwt = JWTManager()
login_manager = LoginManager()


@contextlib.contextmanager
def _db_boot_lock():
    """Serialize boot-time DB initialization across gunicorn workers.

    Every worker runs create_app(), so without a lock they all seed the
    database concurrently and crash on the users.email unique constraint.
    fcntl releases the lock automatically if a worker dies mid-seed. No-op on
    platforms without fcntl (the Windows dev server runs a single process).
    """
    try:
        import fcntl
    except ImportError:
        yield
        return
    lock_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.db_boot.lock')
    with open(lock_path, 'w') as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def create_app(config_name='development'):
    """Create and configure Flask application"""
    template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'templates')
    static_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static')
    app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)
    
    if config_name == 'testing':
        app.config.from_object('app.app_config.TestingConfig')
    elif config_name == 'production':
        app.config.from_object('app.app_config.ProductionConfig')
    else:
        app.config.from_object('app.app_config.DevelopmentConfig')
    
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'jwt-secret-key-change-in-production')
    
    db.init_app(app)
    jwt.init_app(app)
    CORS(app)
    login_manager.init_app(app)
    login_manager.login_view = 'web.login'
    
    @login_manager.user_loader
    def load_user(user_id):
        from app.models import User
        return User.query.get(int(user_id))
    
    from app.models import User
    
    from app.routes.api.auth import auth_bp
    from app.routes.api.aircraft import aircraft_bp
    from app.routes.api.components import components_bp
    from app.routes.api.maintenance import maintenance_bp
    from app.routes.api.predictions import predictions_bp
    from app.routes.api.alerts import alerts_bp
    from app.routes.web import web_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(aircraft_bp, url_prefix='/api/aircraft')
    app.register_blueprint(components_bp, url_prefix='/api/components')
    app.register_blueprint(maintenance_bp, url_prefix='/api/maintenance')
    app.register_blueprint(predictions_bp, url_prefix='/api/predictions')
    app.register_blueprint(alerts_bp, url_prefix='/api/alerts')
    app.register_blueprint(web_bp)
    
    @app.route('/health')
    def health_check():
        return {'status': 'healthy', 'service': 'aircraft-maintenance-api'}, 200
    
    with app.app_context(), _db_boot_lock():
        try:
            db.create_all()
            init_default_data()
        except Exception as e:
            print(f"[WARNING] Database initialization failed: {e}")
            print("[WARNING] App will start without database. Check DATABASE_URL setting.")
    
    return app


def init_default_data():
    """Initialize default users and sample data"""
    from sqlalchemy.exc import IntegrityError
    from app.models import User, Aircraft

    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@aircraft.com',
            full_name='System Administrator',
            role='manager'
        )
        admin.set_password('admin123')
        db.session.add(admin)

    tech = User.query.filter_by(username='tech1').first()
    if not tech:
        tech = User(
            username='tech1',
            email='tech1@aircraft.com',
            full_name='John Technician',
            role='technician'
        )
        tech.set_password('tech123')
        db.session.add(tech)

    try:
        db.session.commit()
    except IntegrityError:
        # Another worker/container committed the same users first - keep theirs
        db.session.rollback()

    if Aircraft.query.first() is None:
        try:
            from app.services.sample_data import create_sample_data
            create_sample_data()
        except Exception as e:
            print(f"Error creating sample data: {e}")
