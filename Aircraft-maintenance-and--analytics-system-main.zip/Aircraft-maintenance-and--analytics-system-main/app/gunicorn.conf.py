# Gunicorn configuration file for Aircraft Maintenance Analytics System
import multiprocessing
import os

# Server socket
bind = "0.0.0.0:" + os.environ.get("WEBSITES_PORT", "5000")

# Worker processes
workers = int(os.environ.get("GUNICORN_WORKERS", (multiprocessing.cpu_count() * 2) + 1))
worker_class = "sync"
threads = 2
timeout = 120
keepalive = 5

# Logging
accesslog = "-"
errorlog = "-"
loglevel = os.environ.get("LOG_LEVEL", "info")

# Security
limit_request_line = 8190
limit_request_fields = 100
limit_request_field_size = 8190

# Restart workers periodically to prevent memory leaks
max_requests = 1000
max_requests_jitter = 50

# Graceful timeout for zero-downtime deploys
graceful_timeout = 30
