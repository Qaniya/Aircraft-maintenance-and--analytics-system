import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(__file__))


def _get_database_uri():
    """Resolve DATABASE_URL with PostgreSQL support for Azure deployment.

    Azure Database for PostgreSQL sets DATABASE_URL as:
      postgresql://user:password@host:port/dbname

    If not set, falls back to local SQLite for development.
    """
    url = os.environ.get('DATABASE_URL', '')
    if not url:
        return f'sqlite:///{os.path.join(basedir, "aircraft_maintenance.db")}'
    # Support postgres:// scheme (SQLAlchemy 1.4+ requires postgresql://)
    if url.startswith('postgres://'):
        url = url.replace('postgres://', 'postgresql://', 1)
    return url


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or os.urandom(32).hex()
    SQLALCHEMY_DATABASE_URI = _get_database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    JSON_SORT_KEYS = False
    # Azure App Service specifics
    WEBSITES_PORT = int(os.environ.get('WEBSITES_PORT', 5000))
    # Azure Key Vault (optional - set AZURE_KEY_VAULT_URL to enable)
    AZURE_KEY_VAULT_URL = os.environ.get('AZURE_KEY_VAULT_URL', '')


class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_ECHO = False


class ProductionConfig(Config):
    DEBUG = False
    SQLALCHEMY_ECHO = False
    # Production requires explicit secrets
    SECRET_KEY = os.environ.get('SECRET_KEY')  # No fallback in production


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


app_config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
