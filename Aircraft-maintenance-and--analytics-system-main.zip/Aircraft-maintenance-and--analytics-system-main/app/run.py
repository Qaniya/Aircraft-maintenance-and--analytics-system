import os
import sys

# Add the app directory to the Python path (for Azure deployment)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app

# Determine environment from Azure or local
config_name = os.environ.get('FLASK_ENV', 'development')
app = create_app(config_name)

if __name__ == '__main__':
    port = int(os.environ.get('WEBSITES_PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=(config_name == 'development'))
