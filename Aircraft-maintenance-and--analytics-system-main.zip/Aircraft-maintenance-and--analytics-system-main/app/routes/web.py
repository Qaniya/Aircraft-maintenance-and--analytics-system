"""
Web routes for template rendering
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import Aircraft, Component, MaintenanceRecord, Alert, FailurePrediction, User
from app.services.prediction_engine import PredictionEngine
from datetime import datetime

web_bp = Blueprint('web', __name__)


@web_bp.route('/')
def index():
    """Dashboard / Home page"""
    if not current_user.is_authenticated:
        return redirect(url_for('web.login'))
    
    stats = {
        'total_aircraft': Aircraft.query.count(),
        'active_aircraft': Aircraft.query.filter(Aircraft.status.in_(['active', 'operational'])).count(),
        'total_components': Component.query.count(),
        'critical_components': Component.query.filter(Component.status == 'unserviceable').count(),
        'pending_maintenance': MaintenanceRecord.query.filter(MaintenanceRecord.status.in_(['scheduled', 'in_progress'])).count(),
        'active_alerts': Alert.query.filter_by(is_active=True, is_acknowledged=False).count()
    }
    
    aircraft = Aircraft.query.limit(10).all()
    alerts = Alert.query.filter_by(is_active=True).order_by(Alert.severity.desc()).limit(5).all()
    maintenance = MaintenanceRecord.query.filter(MaintenanceRecord.status.in_(['scheduled', 'in_progress'])).order_by(MaintenanceRecord.scheduled_date).limit(5).all()
    
    return render_template('index.html', stats=stats, aircraft=aircraft, alerts=alerts, maintenance=maintenance)


@web_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if current_user.is_authenticated:
        return redirect(url_for('web.index'))
    
    if request.method == 'POST':
        data = request.form.to_dict()
        user = User.query.filter_by(username=data.get('username')).first()
        
        if user and user.check_password(data.get('password', '')):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('web.index'))
        
        flash('Invalid username or password', 'danger')
    
    return render_template('auth/login.html')


@web_bp.route('/logout')
@login_required
def logout():
    """Logout"""
    logout_user()
    return redirect(url_for('web.login'))


@web_bp.route('/profile')
@login_required
def profile():
    """User profile"""
    return render_template('auth/profile.html')


@web_bp.route('/aircraft')
@login_required
def aircraft_list():
    """Aircraft list page"""
    aircraft_list = Aircraft.query.all()
    return render_template('aircraft/list.html', aircraft=aircraft_list)


@web_bp.route('/aircraft/<int:aircraft_id>')
@login_required
def aircraft_detail(aircraft_id):
    """Aircraft detail page"""
    aircraft = Aircraft.query.get_or_404(aircraft_id)
    components = Component.query.filter_by(aircraft_id=aircraft_id).all()
    maintenance = MaintenanceRecord.query.filter_by(aircraft_id=aircraft_id).order_by(MaintenanceRecord.scheduled_date.desc()).limit(10).all()
    alerts = Alert.query.filter_by(aircraft_id=aircraft_id).all()
    return render_template('aircraft/detail.html', aircraft=aircraft, components=components, maintenance=maintenance, alerts=alerts)


@web_bp.route('/aircraft/add', methods=['GET', 'POST'])
@login_required
def aircraft_add():
    """Add aircraft page"""
    if request.method == 'POST':
        data = request.form.to_dict()
        aircraft = Aircraft(
            registration_number=data.get('registration_number'),
            aircraft_type=data.get('aircraft_type'),
            model=data.get('model'),
            manufacturer=data.get('manufacturer'),
            year_manufactured=int(data.get('year_manufactured')) if data.get('year_manufactured') else None,
            total_flight_hours=float(data.get('total_flight_hours', 0)),
            total_cycles=int(data.get('total_cycles', 0)),
            status=data.get('status', 'operational')
        )
        db.session.add(aircraft)
        db.session.commit()
        flash('Aircraft added successfully', 'success')
        return redirect(url_for('web.aircraft_list'))
    
    return render_template('aircraft/add.html')


@web_bp.route('/aircraft/<int:aircraft_id>/edit', methods=['GET', 'POST'])
@login_required
def aircraft_edit(aircraft_id):
    """Edit aircraft page"""
    aircraft = Aircraft.query.get_or_404(aircraft_id)
    
    if request.method == 'POST':
        data = request.form.to_dict()
        aircraft.registration_number = data.get('registration_number', aircraft.registration_number)
        aircraft.aircraft_type = data.get('aircraft_type', aircraft.aircraft_type)
        aircraft.model = data.get('model', aircraft.model)
        aircraft.status = data.get('status', aircraft.status)
        db.session.commit()
        flash('Aircraft updated successfully', 'success')
        return redirect(url_for('web.aircraft_detail', aircraft_id=aircraft_id))
    
    return render_template('aircraft/edit.html', aircraft=aircraft)


@web_bp.route('/components')
@login_required
def components_list():
    """Components list page"""
    components = Component.query.all()
    return render_template('components/list.html', components=components)


@web_bp.route('/components/<int:component_id>')
@login_required
def components_detail(component_id):
    """Component detail page"""
    component = Component.query.get_or_404(component_id)
    aircraft = Aircraft.query.get(component.aircraft_id)
    maintenance = MaintenanceRecord.query.filter_by(component_id=component_id).all()
    alerts = Alert.query.filter_by(component_id=component_id).all()
    predictions = FailurePrediction.query.filter_by(component_id=component_id).order_by(FailurePrediction.prediction_date.desc()).limit(5).all()
    
    engine = PredictionEngine()
    health_data = engine.calculate_component_health(component, aircraft)
    health_score = (1 - health_data['failure_probability']) * 100
    
    return render_template('components/detail.html', component=component, maintenance=maintenance, alerts=alerts, predictions=predictions, health=health_score, prediction=health_data)


@web_bp.route('/components/add', methods=['GET', 'POST'])
@login_required
def components_add():
    """Add component page"""
    aircraft_list = Aircraft.query.all()
    
    if request.method == 'POST':
        data = request.form.to_dict()
        component = Component(
            aircraft_id=int(data.get('aircraft_id')),
            part_number=data.get('part_number'),
            serial_number=data.get('serial_number'),
            component_name=data.get('component_name'),
            component_type=data.get('component_type'),
            description=data.get('description'),
            max_hours=float(data.get('max_hours')) if data.get('max_hours') else None,
            max_cycles=int(data.get('max_cycles')) if data.get('max_cycles') else None,
            status='serviceable'
        )
        db.session.add(component)
        db.session.commit()
        flash('Component added successfully', 'success')
        return redirect(url_for('web.components_list'))
    
    return render_template('components/add.html', aircraft=aircraft_list)


@web_bp.route('/components/<int:component_id>/edit', methods=['GET', 'POST'])
@login_required
def components_edit(component_id):
    """Edit component page"""
    component = Component.query.get_or_404(component_id)
    aircraft_list = Aircraft.query.all()
    
    if request.method == 'POST':
        data = request.form.to_dict()
        component.aircraft_id = int(data.get('aircraft_id'))
        component.part_number = data.get('part_number', component.part_number)
        component.serial_number = data.get('serial_number', component.serial_number)
        component.component_name = data.get('component_name', component.component_name)
        component.component_type = data.get('component_type', component.component_type)
        component.description = data.get('description', component.description)
        component.current_hours = float(data.get('current_hours', 0))
        component.max_hours = float(data.get('max_hours')) if data.get('max_hours') else None
        component.current_cycles = int(data.get('current_cycles', 0))
        component.max_cycles = int(data.get('max_cycles')) if data.get('max_cycles') else None
        component.status = data.get('status', component.status)
        db.session.commit()
        flash('Component updated successfully', 'success')
        return redirect(url_for('web.components_detail', component_id=component_id))
    
    return render_template('components/edit.html', component=component, aircraft=aircraft_list)


@web_bp.route('/maintenance')
@login_required
def maintenance_list():
    """Maintenance list page"""
    status_filter = request.args.get('status')
    priority_filter = request.args.get('priority')
    
    query = MaintenanceRecord.query
    if status_filter:
        query = query.filter_by(status=status_filter)
    if priority_filter:
        query = query.filter_by(priority=priority_filter)
    
    records = query.order_by(MaintenanceRecord.scheduled_date.desc()).all()
    return render_template('maintenance/list.html', records=records)


@web_bp.route('/maintenance/<int:record_id>')
@login_required
def maintenance_detail(record_id):
    """Maintenance detail page"""
    record = MaintenanceRecord.query.get_or_404(record_id)
    return render_template('maintenance/detail.html', record=record)


@web_bp.route('/maintenance/add', methods=['GET', 'POST'])
@login_required
def maintenance_add():
    """Add maintenance record page"""
    aircraft_list = Aircraft.query.all()
    components = Component.query.all()
    
    if request.method == 'POST':
        data = request.form.to_dict()
        record = MaintenanceRecord(
            aircraft_id=int(data.get('aircraft_id')),
            component_id=int(data.get('component_id')) if data.get('component_id') else None,
            maintenance_type=data.get('maintenance_type'),
            description=data.get('description'),
            performed_by=current_user.full_name,
            status='scheduled',
            priority=data.get('priority', 'medium')
        )
        db.session.add(record)
        db.session.commit()
        flash('Maintenance record added successfully', 'success')
        return redirect(url_for('web.maintenance_list'))
    
    return render_template('maintenance/add.html', aircraft=aircraft_list, components=components)


@web_bp.route('/maintenance/<int:record_id>/edit', methods=['GET', 'POST'])
@login_required
def maintenance_edit(record_id):
    """Edit maintenance record page"""
    record = MaintenanceRecord.query.get_or_404(record_id)
    aircraft_list = Aircraft.query.all()
    
    if request.method == 'POST':
        data = request.form.to_dict()
        record.aircraft_id = int(data.get('aircraft_id'))
        record.work_order_number = data.get('work_order_number', record.work_order_number)
        record.maintenance_type = data.get('maintenance_type', record.maintenance_type)
        record.priority = data.get('priority', record.priority)
        record.status = data.get('status', record.status)
        record.description = data.get('description', record.description)
        record.performed_by = data.get('performed_by', record.performed_by)
        record.labor_hours = float(data.get('labor_hours', 0))
        record.parts_cost = float(data.get('parts_cost', 0))
        record.labor_cost = float(data.get('labor_cost', 0))
        record.notes = data.get('notes', record.notes)
        db.session.commit()
        flash('Maintenance record updated successfully', 'success')
        return redirect(url_for('web.maintenance_detail', record_id=record_id))
    
    return render_template('maintenance/edit.html', record=record, aircraft=aircraft_list)


@web_bp.route('/maintenance/calendar')
@login_required
def maintenance_calendar():
    """Maintenance calendar page"""
    records = MaintenanceRecord.query.filter(MaintenanceRecord.status.in_(['scheduled', 'in_progress'])).all()
    return render_template('maintenance/calendar.html', records=records)


@web_bp.route('/alerts')
@login_required
def alerts_list():
    """Alerts list page"""
    alerts = Alert.query.filter_by(is_active=True).order_by(Alert.created_at.desc()).all()
    return render_template('alerts/list.html', alerts=alerts)


@web_bp.route('/alerts/<int:alert_id>')
@login_required
def alerts_detail(alert_id):
    """Alert detail page"""
    alert = Alert.query.get_or_404(alert_id)
    return render_template('alerts/detail.html', alert=alert)


@web_bp.route('/alerts/add', methods=['GET', 'POST'])
@login_required
def alerts_add():
    """Create alert page"""
    aircraft_list = Aircraft.query.all()
    components = Component.query.all()
    
    if request.method == 'POST':
        data = request.form.to_dict()
        alert = Alert(
            aircraft_id=int(data.get('aircraft_id')),
            component_id=int(data.get('component_id')) if data.get('component_id') else None,
            alert_type=data.get('alert_type'),
            title=data.get('title'),
            message=data.get('message'),
            severity=data.get('severity', 'medium')
        )
        db.session.add(alert)
        db.session.commit()
        flash('Alert created successfully', 'success')
        return redirect(url_for('web.alerts_list'))
    
    return render_template('alerts/add.html', aircraft=aircraft_list, components=components)


@web_bp.route('/alerts/acknowledge/<int:alert_id>', methods=['POST'])
@login_required
def alerts_acknowledge(alert_id):
    """Acknowledge an alert"""
    alert = Alert.query.get_or_404(alert_id)
    alert.is_acknowledged = True
    alert.acknowledged_by = current_user.user_id
    alert.acknowledged_at = datetime.utcnow()
    db.session.commit()
    flash('Alert acknowledged successfully', 'success')
    return redirect(url_for('web.alerts_detail', alert_id=alert_id))


@web_bp.route('/alerts/resolve/<int:alert_id>', methods=['POST'])
@login_required
def alerts_resolve(alert_id):
    """Resolve an alert"""
    alert = Alert.query.get_or_404(alert_id)
    alert.is_active = False
    db.session.commit()
    flash('Alert resolved successfully', 'success')
    return redirect(url_for('web.alerts_detail', alert_id=alert_id))


@web_bp.route('/predictions')
@login_required
def predictions_list():
    """Predictions list page"""
    predictions = FailurePrediction.query.order_by(FailurePrediction.failure_probability.desc()).limit(50).all()
    return render_template('predictions/list.html', predictions=predictions)


@web_bp.route('/predictions/aircraft/<int:aircraft_id>')
@login_required
def predictions_aircraft(aircraft_id):
    """Aircraft predictions page"""
    aircraft = Aircraft.query.get_or_404(aircraft_id)
    predictions = FailurePrediction.query.filter_by(aircraft_id=aircraft_id).order_by(FailurePrediction.failure_probability.desc()).all()
    
    data = {
        'total_predictions': len(predictions),
        'high_risk_count': sum(1 for p in predictions if p.risk_level == 'high'),
        'medium_risk_count': sum(1 for p in predictions if p.risk_level == 'medium'),
        'predictions': predictions
    }
    
    return render_template('predictions/aircraft.html', aircraft=aircraft, data=data)


@web_bp.route('/api/dashboard/stats')
@login_required
def dashboard_stats():
    """Dashboard statistics API endpoint"""
    stats = {
        'total_aircraft': Aircraft.query.count(),
        'active_aircraft': Aircraft.query.filter(Aircraft.status.in_(['active', 'operational'])).count(),
        'total_components': Component.query.count(),
        'critical_components': Component.query.filter(Component.status == 'unserviceable').count(),
        'pending_maintenance': MaintenanceRecord.query.filter(MaintenanceRecord.status.in_(['scheduled', 'in_progress'])).count(),
        'active_alerts': Alert.query.filter_by(is_active=True, is_acknowledged=False).count(),
        'total_predictions': FailurePrediction.query.count(),
        'high_risk': FailurePrediction.query.filter(FailurePrediction.risk_level.in_(['high', 'critical'])).count()
    }
    return jsonify(stats)