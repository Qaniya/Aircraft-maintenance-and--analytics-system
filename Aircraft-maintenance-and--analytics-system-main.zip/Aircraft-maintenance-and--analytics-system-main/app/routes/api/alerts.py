"""
API Alert routes
"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from app.models import Alert
from datetime import datetime

alerts_bp = Blueprint('alerts', __name__)


@alerts_bp.route('', methods=['GET'])
@jwt_required()
def get_alerts():
    """Get alerts (optionally filter by severity or acknowledgment status)"""
    severity = request.args.get('severity')
    is_acknowledged = request.args.get('is_acknowledged')
    is_active = request.args.get('is_active')
    
    query = Alert.query
    
    if severity:
        query = query.filter_by(severity=severity)
    if is_acknowledged is not None:
        query = query.filter_by(is_acknowledged=is_acknowledged.lower() == 'true')
    if is_active is not None:
        query = query.filter_by(is_active=is_active.lower() == 'true')
    
    alerts = query.order_by(Alert.created_at.desc()).all()
    
    return jsonify([alert.to_dict() for alert in alerts]), 200


@alerts_bp.route('/active', methods=['GET'])
@jwt_required()
def get_active_alerts():
    """Get unacknowledged active alerts"""
    alerts = Alert.query.filter_by(is_acknowledged=False, is_active=True).order_by(Alert.severity.desc()).all()
    
    return jsonify([alert.to_dict() for alert in alerts]), 200


@alerts_bp.route('/<int:alert_id>', methods=['GET'])
@jwt_required()
def get_alert(alert_id):
    """Get specific alert"""
    alert = Alert.query.get(alert_id)
    
    if not alert:
        return jsonify({'error': 'Alert not found'}), 404
    
    return jsonify(alert.to_dict()), 200


@alerts_bp.route('', methods=['POST'])
@jwt_required()
def create_alert():
    """Create new alert"""
    data = request.get_json()
    
    required_fields = ['aircraft_id', 'alert_type', 'title', 'message', 'severity']
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    new_alert = Alert(
        aircraft_id=data['aircraft_id'],
        component_id=data.get('component_id'),
        alert_type=data['alert_type'],
        title=data['title'],
        message=data['message'],
        severity=data['severity'],
        due_date=datetime.strptime(data['due_date'], '%Y-%m-%d').date() if data.get('due_date') else None,
        expires_at=datetime.strptime(data['expires_at'], '%Y-%m-%dT%H:%M:%S').replace(tzinfo=None) if data.get('expires_at') else None
    )
    
    db.session.add(new_alert)
    db.session.commit()
    
    return jsonify(new_alert.to_dict()), 201


@alerts_bp.route('/<int:alert_id>/acknowledge', methods=['PUT'])
@jwt_required()
def acknowledge_alert(alert_id):
    """Acknowledge an alert"""
    claims = get_jwt_identity()
    alert = Alert.query.get(alert_id)
    
    if not alert:
        return jsonify({'error': 'Alert not found'}), 404
    
    alert.is_acknowledged = True
    alert.acknowledged_by = int(claims) if claims else None
    alert.acknowledged_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify(alert.to_dict()), 200


@alerts_bp.route('/<int:alert_id>/resolve', methods=['PUT'])
@jwt_required()
def resolve_alert(alert_id):
    """Resolve an alert"""
    alert = Alert.query.get(alert_id)
    
    if not alert:
        return jsonify({'error': 'Alert not found'}), 404
    
    alert.is_active = False
    db.session.commit()
    
    return jsonify(alert.to_dict()), 200


@alerts_bp.route('/<int:alert_id>', methods=['DELETE'])
@jwt_required()
def delete_alert(alert_id):
    """Delete alert"""
    alert = Alert.query.get(alert_id)
    
    if not alert:
        return jsonify({'error': 'Alert not found'}), 404
    
    db.session.delete(alert)
    db.session.commit()
    
    return jsonify({'message': 'Alert deleted successfully'}), 200


@alerts_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_alert_stats():
    """Get alert statistics"""
    total = Alert.query.count()
    active = Alert.query.filter_by(is_active=True, is_acknowledged=False).count()
    acknowledged = Alert.query.filter_by(is_acknowledged=True).count()
    critical = Alert.query.filter_by(severity='critical', is_active=True).count()
    high = Alert.query.filter_by(severity='high', is_active=True).count()
    
    return jsonify({
        'total': total,
        'active': active,
        'acknowledged': acknowledged,
        'critical': critical,
        'high': high
    }), 200
