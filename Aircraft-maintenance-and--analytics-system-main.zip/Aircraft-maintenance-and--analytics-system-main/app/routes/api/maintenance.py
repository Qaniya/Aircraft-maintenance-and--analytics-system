"""
API Maintenance routes
"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from app.models import MaintenanceRecord
from datetime import datetime

maintenance_bp = Blueprint('maintenance', __name__)


@maintenance_bp.route('', methods=['GET'])
@jwt_required()
def get_maintenance_records():
    """Get maintenance records (filter by aircraft or component)"""
    aircraft_id = request.args.get('aircraft_id', type=int)
    component_id = request.args.get('component_id', type=int)
    status = request.args.get('status')
    
    query = MaintenanceRecord.query
    
    if aircraft_id:
        query = query.filter_by(aircraft_id=aircraft_id)
    if component_id:
        query = query.filter_by(component_id=component_id)
    if status:
        query = query.filter_by(status=status)
    
    records = query.order_by(MaintenanceRecord.scheduled_date.desc()).all()
    
    return jsonify([record.to_dict() for record in records]), 200


@maintenance_bp.route('/<int:record_id>', methods=['GET'])
@jwt_required()
def get_maintenance_record(record_id):
    """Get specific maintenance record"""
    record = MaintenanceRecord.query.get(record_id)
    
    if not record:
        return jsonify({'error': 'Record not found'}), 404
    
    return jsonify(record.to_dict()), 200


@maintenance_bp.route('', methods=['POST'])
@jwt_required()
def create_maintenance_record():
    """Create new maintenance record"""
    claims = get_jwt_identity()
    data = request.get_json()
    
    required_fields = ['description', 'maintenance_date']
    if 'aircraft_id' not in data:
        return jsonify({'error': 'Missing aircraft_id'}), 400
    
    performed_by = data.get('performed_by', 'Unknown')
    if claims:
        performed_by = claims.get('username', performed_by)
    
    new_record = MaintenanceRecord(
        aircraft_id=data['aircraft_id'],
        component_id=data.get('component_id'),
        maintenance_type=data.get('maintenance_type', 'inspection'),
        maintenance_category=data.get('maintenance_category'),
        description=data['description'],
        work_order_number=data.get('work_order_number'),
        performed_by=performed_by,
        scheduled_date=datetime.strptime(data['scheduled_date'], '%Y-%m-%d').date() if data.get('scheduled_date') else None,
        completed_date=datetime.strptime(data['completed_date'], '%Y-%m-%d').date() if data.get('completed_date') else None,
        maintenance_date=datetime.strptime(data['maintenance_date'], '%Y-%m-%d').date() if data.get('maintenance_date') else None,
        downtime_hours=data.get('downtime_hours', 0),
        labor_hours=data.get('labor_hours', 0),
        parts_cost=data.get('parts_cost', 0),
        labor_cost=data.get('labor_cost', 0),
        total_cost=data.get('total_cost', 0),
        status=data.get('status', 'scheduled'),
        priority=data.get('priority', 'medium'),
        notes=data.get('notes'),
        findings=data.get('findings')
    )
    
    db.session.add(new_record)
    db.session.commit()
    
    return jsonify(new_record.to_dict()), 201


@maintenance_bp.route('/<int:record_id>', methods=['PUT'])
@jwt_required()
def update_maintenance_record(record_id):
    """Update maintenance record"""
    record = MaintenanceRecord.query.get(record_id)
    
    if not record:
        return jsonify({'error': 'Record not found'}), 404
    
    data = request.get_json()
    
    if 'status' in data:
        record.status = data['status']
    if 'notes' in data:
        record.notes = data['notes']
    if 'findings' in data:
        record.findings = data['findings']
    if 'completed_date' in data:
        record.completed_date = datetime.strptime(data['completed_date'], '%Y-%m-%d').date()
    
    db.session.commit()
    
    return jsonify(record.to_dict()), 200


@maintenance_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_maintenance_stats():
    """Get maintenance statistics"""
    total = MaintenanceRecord.query.count()
    completed = MaintenanceRecord.query.filter_by(status='completed').count()
    scheduled = MaintenanceRecord.query.filter_by(status='scheduled').count()
    in_progress = MaintenanceRecord.query.filter_by(status='in_progress').count()
    
    from sqlalchemy import func
    total_cost = db.session.query(func.sum(MaintenanceRecord.total_cost)).scalar() or 0
    
    return jsonify({
        'total': total,
        'completed': completed,
        'scheduled': scheduled,
        'in_progress': in_progress,
        'total_cost': float(total_cost)
    }), 200
