"""
API Prediction routes
"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from app import db
from app.models import FailurePrediction, Component, Aircraft

predictions_bp = Blueprint('predictions', __name__)


@predictions_bp.route('', methods=['GET'])
@jwt_required()
def get_predictions():
    """Get failure predictions (filter by aircraft, component, or risk level)"""
    aircraft_id = request.args.get('aircraft_id', type=int)
    component_id = request.args.get('component_id', type=int)
    risk_level = request.args.get('risk_level')
    
    query = FailurePrediction.query
    
    if aircraft_id:
        query = query.filter_by(aircraft_id=aircraft_id)
    if component_id:
        query = query.filter_by(component_id=component_id)
    if risk_level:
        query = query.filter_by(risk_level=risk_level)
    
    predictions = query.order_by(FailurePrediction.failure_probability.desc()).all()
    
    return jsonify([pred.to_dict() for pred in predictions]), 200


@predictions_bp.route('/high-risk', methods=['GET'])
@jwt_required()
def get_high_risk_predictions():
    """Get high and critical risk predictions"""
    predictions = FailurePrediction.query.filter(
        FailurePrediction.risk_level.in_(['high', 'critical'])
    ).order_by(FailurePrediction.failure_probability.desc()).all()
    
    return jsonify([pred.to_dict() for pred in predictions]), 200


@predictions_bp.route('/<int:prediction_id>', methods=['GET'])
@jwt_required()
def get_prediction(prediction_id):
    """Get specific prediction"""
    prediction = FailurePrediction.query.get(prediction_id)
    
    if not prediction:
        return jsonify({'error': 'Prediction not found'}), 404
    
    return jsonify(prediction.to_dict()), 200


@predictions_bp.route('/generate', methods=['POST'])
@jwt_required()
def generate_predictions():
    """Generate new predictions for all components"""
    from app.services.prediction_engine import PredictionEngine
    
    engine = PredictionEngine()
    result = engine.run_predictions()
    
    return jsonify(result), 200


@predictions_bp.route('/aircraft/<int:aircraft_id>', methods=['GET'])
@jwt_required()
def get_aircraft_predictions(aircraft_id):
    """Get predictions for a specific aircraft"""
    predictions = FailurePrediction.query.filter_by(aircraft_id=aircraft_id).order_by(
        FailurePrediction.failure_probability.desc()
    ).all()
    
    return jsonify([pred.to_dict() for pred in predictions]), 200


@predictions_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_prediction_stats():
    """Get prediction statistics"""
    total = FailurePrediction.query.count()
    critical = FailurePrediction.query.filter_by(risk_level='critical').count()
    high = FailurePrediction.query.filter_by(risk_level='high').count()
    medium = FailurePrediction.query.filter_by(risk_level='medium').count()
    low = FailurePrediction.query.filter_by(risk_level='low').count()
    
    avg_probability = db.session.query(db.func.avg(FailurePrediction.failure_probability)).scalar() or 0
    
    return jsonify({
        'total': total,
        'critical': critical,
        'high': high,
        'medium': medium,
        'low': low,
        'average_probability': float(avg_probability)
    }), 200
