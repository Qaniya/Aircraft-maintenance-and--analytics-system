"""
API Component routes
"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from app import db
from app.models import Component
from datetime import datetime

components_bp = Blueprint('components', __name__)


@components_bp.route('', methods=['GET'])
@jwt_required()
def get_all_components():
    """Get all components (optionally filter by aircraft)"""
    aircraft_id = request.args.get('aircraft_id', type=int)
    component_type = request.args.get('type')
    
    query = Component.query
    
    if aircraft_id:
        query = query.filter_by(aircraft_id=aircraft_id)
    if component_type:
        query = query.filter_by(component_type=component_type)
    
    components = query.all()
    return jsonify([comp.to_dict() for comp in components]), 200


@components_bp.route('/<int:component_id>', methods=['GET'])
@jwt_required()
def get_component(component_id):
    """Get specific component"""
    component = Component.query.get(component_id)
    
    if not component:
        return jsonify({'error': 'Component not found'}), 404
    
    return jsonify(component.to_dict()), 200


@components_bp.route('', methods=['POST'])
@jwt_required()
def create_component():
    """Create new component"""
    data = request.get_json()
    
    required_fields = ['aircraft_id', 'serial_number', 'component_type', 'installation_date']
    
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    new_component = Component(
        aircraft_id=data['aircraft_id'],
        part_number=data.get('part_number'),
        serial_number=data['serial_number'],
        component_name=data.get('component_name'),
        component_type=data['component_type'],
        description=data.get('description'),
        installation_date=datetime.strptime(data['installation_date'], '%Y-%m-%d').date(),
        flight_hours_at_install=data.get('flight_hours_at_install', 0),
        cycles_at_install=data.get('cycles_at_install', 0),
        current_hours=data.get('current_hours', 0),
        current_cycles=data.get('current_cycles', 0),
        max_hours=data.get('max_hours'),
        max_cycles=data.get('max_cycles'),
        status=data.get('status', 'serviceable'),
        manufacturer=data.get('manufacturer')
    )
    
    db.session.add(new_component)
    db.session.commit()
    
    return jsonify(new_component.to_dict()), 201


@components_bp.route('/<int:component_id>', methods=['PUT'])
@jwt_required()
def update_component(component_id):
    """Update component"""
    component = Component.query.get(component_id)
    
    if not component:
        return jsonify({'error': 'Component not found'}), 404
    
    data = request.get_json()
    
    if 'status' in data:
        component.status = data['status']
    if 'current_hours' in data:
        component.current_hours = data['current_hours']
    if 'current_cycles' in data:
        component.current_cycles = data['current_cycles']
    if 'last_inspection_date' in data:
        component.last_inspection_date = datetime.strptime(data['last_inspection_date'], '%Y-%m-%d').date()
    
    db.session.commit()
    
    return jsonify(component.to_dict()), 200


@components_bp.route('/<int:component_id>', methods=['DELETE'])
@jwt_required()
def delete_component(component_id):
    """Delete component"""
    component = Component.query.get(component_id)
    
    if not component:
        return jsonify({'error': 'Component not found'}), 404
    
    db.session.delete(component)
    db.session.commit()
    
    return jsonify({'message': 'Component deleted successfully'}), 200


@components_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_component_stats():
    """Get component statistics"""
    total = Component.query.count()
    serviceable = Component.query.filter_by(status='serviceable').count()
    limited = Component.query.filter_by(status='limited').count()
    unserviceable = Component.query.filter_by(status='unserviceable').count()
    
    return jsonify({
        'total': total,
        'serviceable': serviceable,
        'limited': limited,
        'unserviceable': unserviceable
    }), 200
