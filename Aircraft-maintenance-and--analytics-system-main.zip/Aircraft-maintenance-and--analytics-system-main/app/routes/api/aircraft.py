"""
API Aircraft routes
"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from flask import current_app
from app import db
from app.models import Aircraft
from datetime import datetime

aircraft_bp = Blueprint('aircraft', __name__)


@aircraft_bp.route('', methods=['GET'])
@jwt_required()
def get_all_aircraft():
    """Get all aircraft"""
    aircraft_list = Aircraft.query.all()
    return jsonify([ac.to_dict() for ac in aircraft_list]), 200


@aircraft_bp.route('/<int:aircraft_id>', methods=['GET'])
@jwt_required()
def get_aircraft(aircraft_id):
    """Get specific aircraft by ID"""
    aircraft = Aircraft.query.get(aircraft_id)
    
    if not aircraft:
        return jsonify({'error': 'Aircraft not found'}), 404
    
    return jsonify(aircraft.to_dict()), 200


@aircraft_bp.route('', methods=['POST'])
@jwt_required()
def create_aircraft():
    """Create new aircraft"""
    claims = get_jwt_identity()
    if claims and claims.get('role') not in ['manager', 'admin']:
        return jsonify({'error': 'Unauthorized. Manager role required'}), 403
    
    data = request.get_json()
    required_fields = ['registration_number', 'aircraft_type', 'manufacturer']
    
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    new_aircraft = Aircraft(
        registration_number=data['registration_number'],
        aircraft_type=data['aircraft_type'],
        model=data.get('model'),
        manufacturer=data['manufacturer'],
        year_manufactured=data.get('year_manufactured'),
        manufacture_date=datetime.strptime(data['manufacture_date'], '%Y-%m-%d').date() if data.get('manufacture_date') else None,
        total_flight_hours=data.get('total_flight_hours', 0),
        total_cycles=data.get('total_cycles', 0),
        status=data.get('status', 'operational')
    )
    
    db.session.add(new_aircraft)
    db.session.commit()
    
    return jsonify(new_aircraft.to_dict()), 201


@aircraft_bp.route('/<int:aircraft_id>', methods=['PUT'])
@jwt_required()
def update_aircraft(aircraft_id):
    """Update aircraft information"""
    aircraft = Aircraft.query.get(aircraft_id)
    if not aircraft:
        return jsonify({'error': 'Aircraft not found'}), 404
    
    data = request.get_json()
    
    if 'total_flight_hours' in data:
        aircraft.total_flight_hours = data['total_flight_hours']
    if 'total_cycles' in data:
        aircraft.total_cycles = data['total_cycles']
    if 'status' in data:
        aircraft.status = data['status']
    if 'last_maintenance_date' in data:
        aircraft.last_maintenance_date = datetime.strptime(data['last_maintenance_date'], '%Y-%m-%d').date()
    
    db.session.commit()
    
    return jsonify(aircraft.to_dict()), 200


@aircraft_bp.route('/<int:aircraft_id>', methods=['DELETE'])
@jwt_required()
def delete_aircraft(aircraft_id):
    """Delete aircraft"""
    claims = get_jwt_identity()
    if claims and claims.get('role') not in ['manager', 'admin']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    aircraft = Aircraft.query.get(aircraft_id)
    if not aircraft:
        return jsonify({'error': 'Aircraft not found'}), 404
    
    db.session.delete(aircraft)
    db.session.commit()
    
    return jsonify({'message': 'Aircraft deleted successfully'}), 200


@aircraft_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_fleet_stats():
    """Get fleet statistics"""
    total_aircraft = Aircraft.query.count()
    operational = Aircraft.query.filter_by(status='operational').count()
    in_maintenance = Aircraft.query.filter_by(status='maintenance').count()
    grounded = Aircraft.query.filter_by(status='grounded').count()
    active = Aircraft.query.filter_by(status='active').count()
    parked = Aircraft.query.filter_by(status='parked').count()
    
    return jsonify({
        'total_aircraft': total_aircraft,
        'operational': operational,
        'active': active,
        'maintenance': in_maintenance,
        'grounded': grounded,
        'parked': parked
    }), 200
