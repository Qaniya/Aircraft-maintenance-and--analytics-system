"""
SQLAlchemy database models
"""
from datetime import datetime
from flask_login import UserMixin
from app import db
import bcrypt


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    def get_id(self):
        return str(self.user_id)
    
    def set_password(self, password):
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))
    
    def to_dict(self):
        return {
            'user_id': self.user_id,
            'username': self.username,
            'full_name': self.full_name,
            'role': self.role,
            'email': self.email,
            'is_active': self.is_active
        }


class Aircraft(db.Model):
    __tablename__ = 'aircraft'
    
    aircraft_id = db.Column(db.Integer, primary_key=True)
    registration_number = db.Column(db.String(20), unique=True, nullable=False)
    aircraft_type = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50))
    manufacturer = db.Column(db.String(50), nullable=False)
    year_manufactured = db.Column(db.Integer)
    manufacture_date = db.Column(db.Date)
    total_flight_hours = db.Column(db.Numeric(10, 2), default=0)
    total_cycles = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='operational')
    last_maintenance_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    components = db.relationship('Component', backref='aircraft', lazy=True, cascade='all, delete-orphan')
    maintenance_records = db.relationship('MaintenanceRecord', backref='aircraft', lazy=True, cascade='all, delete-orphan')
    alerts = db.relationship('Alert', backref='aircraft', lazy=True, cascade='all, delete-orphan')
    flight_data = db.relationship('FlightData', backref='aircraft', lazy=True, cascade='all, delete-orphan')
    failure_predictions = db.relationship('FailurePrediction', backref='aircraft', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.aircraft_id,
            'aircraft_id': self.aircraft_id,
            'registration_number': self.registration_number,
            'aircraft_type': self.aircraft_type,
            'model': self.model,
            'manufacturer': self.manufacturer,
            'year_manufactured': self.year_manufactured,
            'manufacture_date': self.manufacture_date.isoformat() if self.manufacture_date else None,
            'total_flight_hours': float(self.total_flight_hours) if self.total_flight_hours else 0,
            'total_cycles': self.total_cycles or 0,
            'status': self.status,
            'last_maintenance_date': self.last_maintenance_date.isoformat() if self.last_maintenance_date else None
        }


class Component(db.Model):
    __tablename__ = 'components'
    
    component_id = db.Column(db.Integer, primary_key=True)
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.aircraft_id'), nullable=False)
    part_number = db.Column(db.String(50))
    serial_number = db.Column(db.String(50), unique=True, nullable=False)
    component_name = db.Column(db.String(100))
    component_type = db.Column(db.String(50), nullable=False)
    description = db.Column(db.String(255))
    installation_date = db.Column(db.Date, nullable=False)
    flight_hours_at_install = db.Column(db.Numeric(10, 2), default=0)
    cycles_at_install = db.Column(db.Integer, default=0)
    current_hours = db.Column(db.Numeric(10, 2), default=0)
    current_cycles = db.Column(db.Integer, default=0)
    max_hours = db.Column(db.Numeric(10, 2))
    max_cycles = db.Column(db.Integer)
    last_inspection_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='serviceable')
    manufacturer = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    maintenance_records = db.relationship('MaintenanceRecord', backref='component', lazy=True)
    alerts = db.relationship('Alert', backref='component', lazy=True, cascade='all, delete-orphan')
    failure_predictions = db.relationship('FailurePrediction', backref='component', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.component_id,
            'component_id': self.component_id,
            'aircraft_id': self.aircraft_id,
            'part_number': self.part_number,
            'serial_number': self.serial_number,
            'component_name': self.component_name,
            'component_type': self.component_type,
            'description': self.description,
            'installation_date': self.installation_date.isoformat() if self.installation_date else None,
            'flight_hours_at_install': float(self.flight_hours_at_install) if self.flight_hours_at_install else 0,
            'cycles_at_install': self.cycles_at_install or 0,
            'current_hours': float(self.current_hours) if self.current_hours else 0,
            'current_cycles': self.current_cycles or 0,
            'max_hours': float(self.max_hours) if self.max_hours else None,
            'max_cycles': self.max_cycles,
            'last_inspection_date': self.last_inspection_date.isoformat() if self.last_inspection_date else None,
            'status': self.status,
            'manufacturer': self.manufacturer
        }


class MaintenanceRecord(db.Model):
    __tablename__ = 'maintenance_records'
    
    record_id = db.Column(db.Integer, primary_key=True)
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.aircraft_id'), nullable=False)
    component_id = db.Column(db.Integer, db.ForeignKey('components.component_id'))
    maintenance_type = db.Column(db.String(50), nullable=False)
    maintenance_category = db.Column(db.String(50))
    description = db.Column(db.Text, nullable=False)
    work_order_number = db.Column(db.String(50))
    performed_by = db.Column(db.String(100))
    scheduled_date = db.Column(db.Date)
    completed_date = db.Column(db.Date)
    maintenance_date = db.Column(db.Date)
    downtime_hours = db.Column(db.Numeric(8, 2), default=0)
    labor_hours = db.Column(db.Numeric(8, 2), default=0)
    parts_cost = db.Column(db.Numeric(12, 2), default=0)
    labor_cost = db.Column(db.Numeric(12, 2), default=0)
    total_cost = db.Column(db.Numeric(12, 2), default=0)
    status = db.Column(db.String(20), default='scheduled')
    priority = db.Column(db.String(20), default='medium')
    notes = db.Column(db.Text)
    findings = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.record_id,
            'record_id': self.record_id,
            'aircraft_id': self.aircraft_id,
            'component_id': self.component_id,
            'maintenance_type': self.maintenance_type,
            'maintenance_category': self.maintenance_category,
            'description': self.description,
            'work_order_number': self.work_order_number,
            'performed_by': self.performed_by,
            'scheduled_date': self.scheduled_date.isoformat() if self.scheduled_date else None,
            'completed_date': self.completed_date.isoformat() if self.completed_date else None,
            'maintenance_date': self.maintenance_date.isoformat() if self.maintenance_date else None,
            'downtime_hours': float(self.downtime_hours) if self.downtime_hours else 0,
            'labor_hours': float(self.labor_hours) if self.labor_hours else 0,
            'parts_cost': float(self.parts_cost) if self.parts_cost else 0,
            'labor_cost': float(self.labor_cost) if self.labor_cost else 0,
            'total_cost': float(self.total_cost) if self.total_cost else 0,
            'status': self.status,
            'priority': self.priority,
            'notes': self.notes,
            'findings': self.findings
        }


class Alert(db.Model):
    __tablename__ = 'alerts'
    
    alert_id = db.Column(db.Integer, primary_key=True)
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.aircraft_id'), nullable=False)
    component_id = db.Column(db.Integer, db.ForeignKey('components.component_id'))
    alert_type = db.Column(db.String(50), nullable=False)
    severity = db.Column(db.String(20), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_acknowledged = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    acknowledged_by = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    acknowledged_at = db.Column(db.DateTime)
    due_date = db.Column(db.Date)
    expires_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.alert_id,
            'alert_id': self.alert_id,
            'aircraft_id': self.aircraft_id,
            'component_id': self.component_id,
            'alert_type': self.alert_type,
            'severity': self.severity,
            'title': self.title,
            'message': self.message,
            'is_acknowledged': self.is_acknowledged,
            'is_active': self.is_active,
            'acknowledged_by': self.acknowledged_by,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class FailurePrediction(db.Model):
    __tablename__ = 'failure_predictions'
    
    prediction_id = db.Column(db.Integer, primary_key=True)
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.aircraft_id'), nullable=False)
    component_id = db.Column(db.Integer, db.ForeignKey('components.component_id'), nullable=False)
    prediction_date = db.Column(db.DateTime, default=datetime.utcnow)
    prediction_type = db.Column(db.String(50), default='failure')
    failure_probability = db.Column(db.Numeric(5, 4), nullable=False)
    risk_level = db.Column(db.String(20), nullable=False)
    estimated_remaining_hours = db.Column(db.Numeric(10, 2))
    estimated_remaining_cycles = db.Column(db.Integer)
    confidence_score = db.Column(db.Numeric(5, 4))
    prediction_model = db.Column(db.String(50), default='usage_based')
    features_used = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.prediction_id,
            'prediction_id': self.prediction_id,
            'aircraft_id': self.aircraft_id,
            'component_id': self.component_id,
            'prediction_date': self.prediction_date.isoformat() if self.prediction_date else None,
            'prediction_type': self.prediction_type,
            'failure_probability': float(self.failure_probability) if self.failure_probability else 0,
            'risk_level': self.risk_level,
            'estimated_remaining_hours': float(self.estimated_remaining_hours) if self.estimated_remaining_hours else None,
            'estimated_remaining_cycles': self.estimated_remaining_cycles,
            'confidence_score': float(self.confidence_score) if self.confidence_score else None,
            'prediction_model': self.prediction_model,
            'features_used': self.features_used
        }


class FlightData(db.Model):
    __tablename__ = 'flight_data'
    
    flight_id = db.Column(db.Integer, primary_key=True)
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.aircraft_id'), nullable=False)
    flight_date = db.Column(db.Date, nullable=False)
    flight_number = db.Column(db.String(20))
    origin = db.Column(db.String(10))
    destination = db.Column(db.String(10))
    flight_hours = db.Column(db.Numeric(6, 2))
    flight_cycles = db.Column(db.Integer, default=1)
    takeoffs = db.Column(db.Integer, default=1)
    landings = db.Column(db.Integer, default=1)
    fuel_burned = db.Column(db.Numeric(10, 2))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'flight_id': self.flight_id,
            'aircraft_id': self.aircraft_id,
            'flight_date': self.flight_date.isoformat() if self.flight_date else None,
            'flight_number': self.flight_number,
            'origin': self.origin,
            'destination': self.destination,
            'flight_hours': float(self.flight_hours) if self.flight_hours else None,
            'flight_cycles': self.flight_cycles,
            'takeoffs': self.takeoffs,
            'landings': self.landings,
            'fuel_burned': float(self.fuel_burned) if self.fuel_burned else None,
            'notes': self.notes
        }
