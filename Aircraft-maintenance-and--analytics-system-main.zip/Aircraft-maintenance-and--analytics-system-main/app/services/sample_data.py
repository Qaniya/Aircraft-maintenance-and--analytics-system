"""
Sample data generator for testing and demonstration
Generates realistic aircraft maintenance data
"""
import random
from datetime import datetime, timedelta
from app import db
from app.models import Aircraft, Component, MaintenanceRecord, Alert, FlightData, FailurePrediction


AIRCRAFT_TEMPLATES = [
    {'type': 'B737', 'model': '737-800', 'manufacturer': 'Boeing'},
    {'type': 'B737', 'model': '737 MAX 8', 'manufacturer': 'Boeing'},
    {'type': 'B737', 'model': '737-900ER', 'manufacturer': 'Boeing'},
    {'type': 'B777', 'model': '777-300ER', 'manufacturer': 'Boeing'},
    {'type': 'B787', 'model': '787-9 Dreamliner', 'manufacturer': 'Boeing'},
    {'type': 'A320', 'model': 'A320neo', 'manufacturer': 'Airbus'},
    {'type': 'A320', 'model': 'A320ceo', 'manufacturer': 'Airbus'},
    {'type': 'A321', 'model': 'A321neo', 'manufacturer': 'Airbus'},
    {'type': 'A350', 'model': 'A350-900', 'manufacturer': 'Airbus'},
    {'type': 'A380', 'model': 'A380-800', 'manufacturer': 'Airbus'},
    {'type': 'E190', 'model': 'E190-E2', 'manufacturer': 'Embraer'},
    {'type': 'E175', 'model': 'E175-E2', 'manufacturer': 'Embraer'},
    {'type': 'CRJ', 'model': 'CRJ-900', 'manufacturer': 'Bombardier'},
]

COMPONENT_TYPES = {
    'Engine': [
        'Left Engine', 'Right Engine', 'Engine Control Unit', 'Thrust Reverser',
        'Engine Bleed Air Valve', 'Fuel Control Unit'
    ],
    'Landing Gear': [
        'Left Main Landing Gear', 'Right Main Landing Gear', 'Nose Landing Gear',
        'Brake System', 'Tire Assembly', 'Anti-Skid System'
    ],
    'Avionics': [
        'Flight Management System', 'Autopilot Computer', 'Weather Radar',
        'Radio Altimeter', 'VOR/ILS Receiver', 'ADF System'
    ],
    'APU': [
        'Auxiliary Power Unit', 'APU Controller', 'APU Generator'
    ],
    'Hydraulics': [
        'Hydraulic Pump', 'Hydraulic Reservoir', 'Flight Control Actuator',
        'Hydraulic Filter', 'Hydraulic Accumulator'
    ],
    'Pneumatics': [
        'Air Conditioning Pack', 'Bleed Air Valve', 'Pressurization Controller'
    ],
    'Electrical': [
        'Generator', 'Battery', 'Emergency Power Unit', 'Inverter'
    ],
    'Fuel': [
        'Fuel Pump', 'Fuel Quantity Indicator', 'Fuel Valve', 'Fuel Filter'
    ]
}

MANUFACTURERS = ['Boeing', 'Airbus', 'Embraer', 'Bombardier']
AIRPORTS = ['JFK', 'LAX', 'ORD', 'DFW', 'DEN', 'ATL', 'SFO', 'SEA', 'MIA', 'BOS', 
            'CLT', 'LAS', 'MCO', 'EWR', 'PHX', 'IAH', 'MSP', 'DTW', 'PHL', 'LGA',
            'SLC', 'BWI', 'SAN', 'IAD', 'DCA', 'MDW', 'FLL', 'SJC', 'TPA', 'PDX']

MAINTENANCE_TYPES = ['inspection', 'repair', 'replacement', 'overhaul', 'modification', 'testing', 'calibration']
PRIORITIES = ['low', 'medium', 'high', 'critical']
STATUSES = ['scheduled', 'in_progress', 'completed', 'cancelled']
AIRCRAFT_STATUSES = ['active', 'operational', 'maintenance', 'parked', 'grounded']
COMPONENT_STATUSES = ['serviceable', 'limited', 'unserviceable']
ALERT_TYPES = ['hour_limit', 'cycle_limit', 'inspection', 'maintenance', 'prediction', 'safety']
SEVERITIES = ['low', 'medium', 'high', 'critical']


def generate_registration_number():
    """Generate a realistic aircraft registration number"""
    prefixes = ['N', 'G-', 'F-', 'D-', 'JA', 'VN', 'VT', 'PK', 'A7-', 'OE-']
    prefix = random.choice(prefixes)
    
    if prefix == 'N':
        return f"N{random.randint(100, 999)}{chr(random.randint(65, 90))}{chr(random.randint(65, 90))}"
    else:
        return f"{prefix}{random.randint(100, 999)}"


def generate_part_number(aircraft_reg):
    """Generate a realistic part number"""
    return f"{aircraft_reg[:2]}-{random.randint(1000, 9999)}"


def generate_serial_number():
    """Generate a unique serial number"""
    return f"SN-{random.randint(100000, 999999)}"


def generate_work_order():
    """Generate a work order number"""
    year = datetime.now().year
    return f"WO-{year}{random.randint(10000, 99999)}"


def create_sample_data(num_aircraft=20, components_per_aircraft=10, maintenance_per_component=5, flights_per_aircraft=50):
    """Create comprehensive sample data for testing"""
    
    if Aircraft.query.first() is not None:
        print("Sample data already exists. Skipping...")
        return
    
    print(f"Creating sample data: {num_aircraft} aircraft, ~{num_aircraft * components_per_aircraft} components...")
    
    aircraft_list = []
    all_components = []
    
    for i in range(num_aircraft):
        template = random.choice(AIRCRAFT_TEMPLATES)
        reg_num = generate_registration_number()
        
        manufacture_year = random.randint(2010, 2024)
        manufacture_date = datetime(manufacture_year, random.randint(1, 12), random.randint(1, 28)).date()
        
        total_hours = random.uniform(1000, 25000)
        total_cycles = int(total_hours / 2) + random.randint(100, 500)
        
        status = random.choices(
            AIRCRAFT_STATUSES, 
            weights=[60, 20, 10, 5, 5],
            k=1
        )[0]
        
        aircraft = Aircraft(
            registration_number=reg_num,
            aircraft_type=template['type'],
            model=template['model'],
            manufacturer=template['manufacturer'],
            year_manufactured=manufacture_year,
            manufacture_date=manufacture_date,
            total_flight_hours=total_hours,
            total_cycles=total_cycles,
            status=status
        )
        db.session.add(aircraft)
        aircraft_list.append(aircraft)
    
    db.session.flush()
    
    for aircraft in aircraft_list:
        num_comps = random.randint(components_per_aircraft - 3, components_per_aircraft + 3)
        selected_types = random.sample(list(COMPONENT_TYPES.keys()), min(num_comps, len(COMPONENT_TYPES)))
        
        for comp_type in selected_types:
            for part_name in COMPONENT_TYPES[comp_type][:2]:
                installation_days_ago = random.randint(30, 1500)
                install_date = datetime.now().date() - timedelta(days=installation_days_ago)
                
                hours_at_install = aircraft.total_flight_hours * random.uniform(0.3, 0.9)
                cycles_at_install = aircraft.total_cycles * random.uniform(0.3, 0.9)
                
                max_hours = random.choice([5000, 8000, 10000, 15000, 20000, 25000])
                max_cycles = random.choice([2000, 4000, 6000, 8000, 10000])
                
                current_hours = hours_at_install + random.uniform(0, max_hours * 0.8)
                current_cycles = int(cycles_at_install + random.uniform(0, max_cycles * 0.8))
                
                hours_usage_ratio = current_hours / max_hours if max_hours else 0
                cycles_usage_ratio = current_cycles / max_cycles if max_cycles else 0
                
                if hours_usage_ratio > 0.9 or cycles_usage_ratio > 0.9:
                    status = random.choice(['unserviceable', 'limited'])
                elif hours_usage_ratio > 0.75 or cycles_usage_ratio > 0.75:
                    status = random.choice(['limited', 'serviceable', 'serviceable'])
                else:
                    status = random.choice(['serviceable', 'serviceable', 'serviceable', 'serviceable'])
                
                component = Component(
                    aircraft_id=aircraft.aircraft_id,
                    part_number=generate_part_number(aircraft.registration_number),
                    serial_number=generate_serial_number(),
                    component_name=part_name,
                    component_type=comp_type,
                    description=f"{part_name} for {aircraft.registration_number}",
                    installation_date=install_date,
                    flight_hours_at_install=hours_at_install,
                    cycles_at_install=int(cycles_at_install),
                    current_hours=current_hours,
                    current_cycles=current_cycles,
                    max_hours=max_hours,
                    max_cycles=max_cycles,
                    last_inspection_date=datetime.now().date() - timedelta(days=random.randint(1, 180)),
                    status=status,
                    manufacturer=aircraft.manufacturer
                )
                db.session.add(component)
                all_components.append(component)
    
    db.session.flush()
    
    print(f"Creating {len(all_components) * maintenance_per_component} maintenance records...")
    for component in all_components:
        aircraft = component.aircraft
        num_records = random.randint(2, maintenance_per_component)
        
        for _ in range(num_records):
            maint_type = random.choice(MAINTENANCE_TYPES)
            
            days_ago = random.randint(1, 500)
            maintenance_date = datetime.now().date() - timedelta(days=days_ago)
            
            completed = random.random() > 0.15
            status = 'completed' if completed else random.choice(['scheduled', 'in_progress'])
            
            labor_hours = random.uniform(1, 40) if maint_type in ['repair', 'replacement', 'overhaul'] else random.uniform(0.5, 8)
            parts_cost = random.uniform(100, 8000) if maint_type in ['replacement', 'overhaul'] else random.uniform(20, 1000)
            labor_cost = labor_hours * random.uniform(75, 150)
            total_cost = parts_cost + labor_cost
            
            scheduled_days_ahead = random.randint(1, 90) if not completed else 0
            scheduled_date = maintenance_date + timedelta(days=scheduled_days_ahead)
            
            priority = random.choices(PRIORITIES, weights=[20, 40, 30, 10], k=1)[0]
            
            findings = None
            if completed and random.random() > 0.5:
                findings_options = [
                    'All systems nominal after maintenance',
                    'Component within acceptable limits',
                    'Replaced worn parts as per manufacturer guidelines',
                    'No discrepancies found',
                    'Minor adjustments required - completed',
                    'Full system test passed'
                ]
                findings = random.choice(findings_options)
            
            notes = None
            if random.random() > 0.7:
                notes_options = [
                    'Customer request',
                    'Scheduled maintenance',
                    'FAA requirement',
                    'Manufacturer service bulletin',
                    'Airworthiness directive compliance'
                ]
                notes = random.choice(notes_options)
            
            record = MaintenanceRecord(
                aircraft_id=aircraft.aircraft_id,
                component_id=component.component_id,
                maintenance_type=maint_type,
                maintenance_category=maint_type,
                description=f"{maint_type.title()} of {component.component_name}",
                work_order_number=generate_work_order(),
                performed_by=random.choice(['John Smith', 'Jane Doe', 'Mike Johnson', 'Sarah Wilson', 'Tom Brown']),
                scheduled_date=scheduled_date,
                completed_date=maintenance_date if completed else None,
                maintenance_date=maintenance_date,
                downtime_hours=labor_hours,
                labor_hours=labor_hours,
                parts_cost=parts_cost,
                labor_cost=labor_cost,
                total_cost=total_cost,
                status=status,
                priority=priority,
                findings=findings,
                notes=notes
            )
            db.session.add(record)
    
    print("Creating alerts...")
    alert_count = 0
    for component in all_components:
        aircraft = component.aircraft
        
        hours_usage = (component.current_hours / component.max_hours) if component.max_hours else 0
        cycles_usage = (component.current_cycles / component.max_cycles) if component.max_cycles else 0
        
        if hours_usage > 0.85:
            severity = 'critical' if hours_usage > 0.95 else 'high'
            alert = Alert(
                aircraft_id=aircraft.aircraft_id,
                component_id=component.component_id,
                alert_type='hour_limit',
                title=f'Hours limit approaching for {component.part_number}',
                message=f'Component has used {component.current_hours:.0f} of {component.max_hours:.0f} allowable hours ({hours_usage*100:.1f}%)',
                severity=severity,
                due_date=datetime.now().date() + timedelta(days=random.randint(7, 30)),
                is_active=True
            )
            db.session.add(alert)
            alert_count += 1
        
        if cycles_usage > 0.85:
            severity = 'critical' if cycles_usage > 0.95 else 'high'
            alert = Alert(
                aircraft_id=aircraft.aircraft_id,
                component_id=component.component_id,
                alert_type='cycle_limit',
                title=f'Cycles limit approaching for {component.part_number}',
                message=f'Component has used {component.current_cycles} of {component.max_cycles} allowable cycles ({cycles_usage*100:.1f}%)',
                severity=severity,
                due_date=datetime.now().date() + timedelta(days=random.randint(7, 30)),
                is_active=True
            )
            db.session.add(alert)
            alert_count += 1
        
        if component.status in ['limited', 'unserviceable']:
            alert = Alert(
                aircraft_id=aircraft.aircraft_id,
                component_id=component.component_id,
                alert_type='maintenance',
                title=f'Component status: {component.status}',
                message=f'{component.component_name} ({component.serial_number}) requires attention',
                severity='high' if component.status == 'unserviceable' else 'medium',
                due_date=datetime.now().date() + timedelta(days=random.randint(1, 14)),
                is_active=True
            )
            db.session.add(alert)
            alert_count += 1
        
        if random.random() < 0.1:
            alert = Alert(
                aircraft_id=aircraft.aircraft_id,
                component_id=component.component_id,
                alert_type='inspection',
                title=f'Inspection due for {component.part_number}',
                message='Scheduled inspection is due based on maintenance calendar',
                severity=random.choice(['low', 'medium']),
                due_date=datetime.now().date() + timedelta(days=random.randint(1, 30)),
                is_active=True
            )
            db.session.add(alert)
            alert_count += 1
    
    print(f"Creating {len(aircraft_list) * flights_per_aircraft} flight records...")
    for aircraft in aircraft_list:
        for _ in range(flights_per_aircraft):
            days_ago = random.randint(1, 365)
            flight_date = datetime.now().date() - timedelta(days=days_ago)
            
            origin = random.choice(AIRPORTS)
            destination = random.choice([a for a in AIRPORTS if a != origin])
            
            flight_hours = random.uniform(1, 7)
            flight_cycles = random.randint(1, 3)
            takeoffs = flight_cycles
            landings = flight_cycles
            
            base_fuel = 2000
            fuel_multiplier = 1 + (flight_hours / 5)
            fuel_burned = base_fuel * fuel_multiplier * random.uniform(0.9, 1.1)
            
            flight = FlightData(
                aircraft_id=aircraft.aircraft_id,
                flight_date=flight_date,
                flight_number=f"{aircraft.registration_number[:2]}{random.randint(100, 999)}",
                origin=origin,
                destination=destination,
                flight_hours=flight_hours,
                flight_cycles=flight_cycles,
                takeoffs=takeoffs,
                landings=landings,
                fuel_burned=fuel_burned
            )
            db.session.add(flight)
    
    print("Creating failure predictions...")
    prediction_count = 0
    for component in all_components:
        aircraft = component.aircraft
        
        hours_usage = (component.current_hours / component.max_hours) if component.max_hours else 0
        cycles_usage = (component.current_cycles / component.max_cycles) if component.max_cycles else 0
        max_usage = max(hours_usage, cycles_usage)
        
        base_probability = max_usage
        
        if component.last_inspection_date:
            days_since_inspection = (datetime.now().date() - component.last_inspection_date).days
            if days_since_inspection > 180:
                base_probability += 0.15
            elif days_since_inspection > 90:
                base_probability += 0.08
        
        maintenance_count = MaintenanceRecord.query.filter_by(
            component_id=component.component_id,
            status='completed'
        ).count()
        if maintenance_count > 5:
            base_probability -= 0.10
        elif maintenance_count > 2:
            base_probability -= 0.05
        
        failure_probability = max(0.01, min(0.99, base_probability))
        
        if failure_probability >= 0.85:
            risk_level = 'critical'
        elif failure_probability >= 0.70:
            risk_level = 'high'
        elif failure_probability >= 0.40:
            risk_level = 'medium'
        else:
            risk_level = 'low'
        
        estimated_remaining_hours = None
        estimated_remaining_cycles = None
        
        if component.max_hours and component.current_hours:
            remaining_hours = float(component.max_hours) - float(component.current_hours)
            estimated_remaining_hours = max(0, remaining_hours * (1 - failure_probability))
        
        if component.max_cycles and component.current_cycles:
            remaining_cycles = component.max_cycles - component.current_cycles
            estimated_remaining_cycles = max(0, int(remaining_cycles * (1 - failure_probability)))
        
        prediction = FailurePrediction(
            aircraft_id=aircraft.aircraft_id,
            component_id=component.component_id,
            prediction_type='failure',
            failure_probability=failure_probability,
            risk_level=risk_level,
            estimated_remaining_hours=estimated_remaining_hours,
            estimated_remaining_cycles=estimated_remaining_cycles,
            confidence_score=random.uniform(0.65, 0.90),
            prediction_model='usage_based',
            features_used={
                'hours_utilization': float(hours_usage),
                'cycles_utilization': float(cycles_usage),
                'days_since_inspection': (datetime.now().date() - component.last_inspection_date).days if component.last_inspection_date else 0,
                'maintenance_count': maintenance_count
            }
        )
        db.session.add(prediction)
        prediction_count += 1
    
    db.session.commit()
    
    print(f"\nSample data created successfully!")
    print(f"  Aircraft: {len(aircraft_list)}")
    print(f"  Components: {len(all_components)}")
    print(f"  Maintenance Records: {MaintenanceRecord.query.count()}")
    print(f"  Alerts: {alert_count}")
    print(f"  Flight Records: {FlightData.query.count()}")
    print(f"  Predictions: {prediction_count}")


def reset_sample_data():
    """Clear all data and regenerate"""
    db.drop_all()
    db.create_all()
    create_sample_data()
