"""
Analytics utilities for dashboard data preparation
"""
from sqlalchemy import func, text
from app import db
from app.models import Aircraft, Component, MaintenanceRecord, Alert, FailurePrediction, FlightData


def get_fleet_health_summary():
    """Get overall fleet health metrics"""
    total_aircraft = Aircraft.query.count()
    total_components = Component.query.count()
    critical_components = Component.query.filter_by(status='unserviceable').count()
    warning_components = Component.query.filter_by(status='limited').count()
    healthy_components = Component.query.filter_by(status='serviceable').count()
    
    return {
        'total_aircraft': total_aircraft,
        'total_components': total_components,
        'critical_components': critical_components,
        'warning_components': warning_components,
        'healthy_components': healthy_components
    }


def get_maintenance_cost_trend(months=12):
    """Get maintenance costs over time"""
    from datetime import datetime, timedelta
    
    start_date = datetime.now() - timedelta(days=months * 30)
    
    records = MaintenanceRecord.query.filter(
        MaintenanceRecord.maintenance_date >= start_date,
        MaintenanceRecord.status == 'completed'
    ).all()
    
    monthly_data = {}
    for record in records:
        if record.maintenance_date:
            month_key = record.maintenance_date.strftime('%Y-%m')
            if month_key not in monthly_data:
                monthly_data[month_key] = {'total_cost': 0, 'count': 0}
            monthly_data[month_key]['total_cost'] += float(record.total_cost or 0)
            monthly_data[month_key]['count'] += 1
    
    return [
        {'month': month, 'total_cost': data['total_cost'], 'maintenance_count': data['count']}
        for month, data in sorted(monthly_data.items())
    ]


def get_component_type_breakdown():
    """Get component count by type"""
    results = db.session.query(
        Component.component_type,
        func.count(Component.component_id).label('count')
    ).group_by(Component.component_type).all()
    
    return [{'type': r[0], 'count': r[1]} for r in results]


def get_alert_severity_breakdown():
    """Get alert count by severity"""
    results = db.session.query(
        Alert.severity,
        func.count(Alert.alert_id).label('count')
    ).filter(Alert.is_active == True).group_by(Alert.severity).all()
    
    return [{'severity': r[0], 'count': r[1]} for r in results]


def get_predictions_by_risk():
    """Get prediction count by risk level"""
    results = db.session.query(
        FailurePrediction.risk_level,
        func.count(FailurePrediction.prediction_id).label('count')
    ).group_by(FailurePrediction.risk_level).all()
    
    return [{'risk_level': r[0], 'count': r[1]} for r in results]


def get_aircraft_utilization():
    """Get aircraft utilization statistics"""
    aircraft = Aircraft.query.all()
    
    total_hours = sum(float(a.total_flight_hours or 0) for a in aircraft)
    total_cycles = sum(a.total_cycles or 0 for a in aircraft)
    
    return {
        'total_flight_hours': total_hours,
        'total_flight_cycles': total_cycles,
        'average_flight_hours': total_hours / len(aircraft) if aircraft else 0,
        'average_flight_cycles': total_cycles / len(aircraft) if aircraft else 0
    }


def get_maintenance_types_breakdown():
    """Get maintenance count by type"""
    results = db.session.query(
        MaintenanceRecord.maintenance_type,
        func.count(MaintenanceRecord.record_id).label('count')
    ).group_by(MaintenanceRecord.maintenance_type).all()
    
    return [{'type': r[0], 'count': r[1]} for r in results]


def get_aircraft_status_breakdown():
    """Get aircraft count by status"""
    results = db.session.query(
        Aircraft.status,
        func.count(Aircraft.aircraft_id).label('count')
    ).group_by(Aircraft.status).all()
    
    return [{'status': r[0], 'count': r[1]} for r in results]
