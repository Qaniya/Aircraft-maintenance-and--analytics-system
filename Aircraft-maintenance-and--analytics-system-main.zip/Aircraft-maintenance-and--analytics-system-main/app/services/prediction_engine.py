"""
Failure prediction engine using usage-based model
"""
from datetime import datetime, timedelta
from app import db
from app.models import Component, Aircraft, MaintenanceRecord, FailurePrediction, Alert


class PredictionEngine:
    """
    Failure prediction using component usage metrics
    """
    
    def __init__(self):
        self.HIGH_RISK_THRESHOLD = 0.70
        self.CRITICAL_RISK_THRESHOLD = 0.85
    
    def calculate_component_health(self, component, aircraft):
        """Calculate health score for a single component"""
        
        current_flight_hours = float(aircraft.total_flight_hours or 0)
        current_cycles = aircraft.total_cycles or 0
        
        hours_since_install = current_flight_hours - float(component.flight_hours_at_install or 0)
        cycles_since_install = current_cycles - (component.cycles_at_install or 0)
        
        hours_utilization = 0
        if component.max_hours:
            hours_utilization = hours_since_install / float(component.max_hours)
        
        cycles_utilization = 0
        if component.max_cycles:
            cycles_utilization = cycles_since_install / component.max_cycles
        
        utilization_ratio = max(hours_utilization, cycles_utilization)
        
        maintenance_count = MaintenanceRecord.query.filter_by(
            component_id=component.component_id,
            status='completed'
        ).count()
        
        days_since_inspection = 0
        if component.last_inspection_date:
            days_since_inspection = (datetime.now().date() - component.last_inspection_date).days
        elif component.installation_date:
            days_since_inspection = (datetime.now().date() - component.installation_date).days
        
        base_probability = utilization_ratio
        
        if days_since_inspection > 180:
            base_probability += 0.15
        elif days_since_inspection > 90:
            base_probability += 0.08
        
        if maintenance_count > 5:
            base_probability -= 0.10
        elif maintenance_count > 2:
            base_probability -= 0.05
        
        failure_probability = max(0.01, min(0.99, base_probability))
        
        if failure_probability >= self.CRITICAL_RISK_THRESHOLD:
            risk_level = 'critical'
        elif failure_probability >= self.HIGH_RISK_THRESHOLD:
            risk_level = 'high'
        elif failure_probability >= 0.40:
            risk_level = 'medium'
        else:
            risk_level = 'low'
        
        estimated_remaining_hours = None
        estimated_remaining_cycles = None
        
        if component.max_hours:
            remaining_hours = float(component.max_hours) - hours_since_install
            estimated_remaining_hours = max(0, remaining_hours * (1 - failure_probability))
        
        if component.max_cycles:
            remaining_cycles = component.max_cycles - cycles_since_install
            estimated_remaining_cycles = max(0, int(remaining_cycles * (1 - failure_probability)))
        
        return {
            'failure_probability': failure_probability,
            'risk_level': risk_level,
            'estimated_remaining_hours': estimated_remaining_hours,
            'estimated_remaining_cycles': estimated_remaining_cycles,
            'confidence_score': 0.75,
            'features_used': {
                'hours_utilization': float(hours_utilization),
                'cycles_utilization': float(cycles_utilization),
                'days_since_inspection': days_since_inspection,
                'maintenance_count': maintenance_count
            }
        }
    
    def predict_failure(self, component, aircraft=None):
        """Predict failure for a single component"""
        if aircraft is None:
            aircraft = Aircraft.query.get(component.aircraft_id)
        if aircraft is None:
            return None
        return self.calculate_component_health(component, aircraft)
    
    def run_predictions(self):
        """Run predictions for all components"""
        components = Component.query.all()
        predictions_created = 0
        alerts_created = 0
        
        FailurePrediction.query.delete()
        
        for component in components:
            aircraft = Aircraft.query.get(component.aircraft_id)
            
            if not aircraft:
                continue
            
            health_data = self.calculate_component_health(component, aircraft)
            
            prediction = FailurePrediction(
                aircraft_id=component.aircraft_id,
                component_id=component.component_id,
                prediction_type='failure',
                failure_probability=health_data['failure_probability'],
                risk_level=health_data['risk_level'],
                estimated_remaining_hours=health_data['estimated_remaining_hours'],
                estimated_remaining_cycles=health_data['estimated_remaining_cycles'],
                confidence_score=health_data['confidence_score'],
                prediction_model='usage_based',
                features_used=health_data['features_used']
            )
            
            db.session.add(prediction)
            predictions_created += 1
            
            if health_data['risk_level'] == 'critical':
                component.status = 'unserviceable'
            elif health_data['risk_level'] == 'high':
                component.status = 'limited'
            
            if health_data['risk_level'] in ['high', 'critical']:
                existing_alert = Alert.query.filter_by(
                    component_id=component.component_id,
                    alert_type='prediction',
                    is_active=True
                ).first()
                
                if not existing_alert:
                    alert = Alert(
                        aircraft_id=component.aircraft_id,
                        component_id=component.component_id,
                        alert_type='prediction',
                        severity=health_data['risk_level'],
                        title=f'Predicted failure risk for {component.part_number or component.component_name}',
                        message=f'{component.component_name} has {health_data["failure_probability"]*100:.1f}% failure probability. '
                                f'Estimated remaining hours: {health_data["estimated_remaining_hours"]:.0f if health_data["estimated_remaining_hours"] else "N/A"}',
                        due_date=datetime.now().date() + timedelta(days=7),
                        is_active=True
                    )
                    db.session.add(alert)
                    alerts_created += 1
        
        db.session.commit()
        
        return {
            'predictions_created': predictions_created,
            'alerts_created': alerts_created,
            'timestamp': datetime.now().isoformat()
        }


def run_prediction_job():
    """Wrapper function for scheduled execution"""
    engine = PredictionEngine()
    result = engine.run_predictions()
    print(f"Prediction job completed: {result}")
    return result
