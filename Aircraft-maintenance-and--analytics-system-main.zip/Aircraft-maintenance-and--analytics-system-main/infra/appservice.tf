# ---------------------------------------------------------------------------
# App Service Plan (Linux)
# ---------------------------------------------------------------------------
resource "azurerm_service_plan" "main" {
  name                = "asp-${var.project_name}-${var.environment}"
  resource_group_name = local.resource_group_name
  location            = local.location
  os_type             = "Linux"
  sku_name            = var.app_service_sku
  worker_count        = var.app_instance_count
  tags                = local.common_tags
}

# ---------------------------------------------------------------------------
# Linux Web App (Container)
# ---------------------------------------------------------------------------
resource "azurerm_linux_web_app" "main" {
  name                = "app-${var.project_name}-${var.environment}"
  resource_group_name = local.resource_group_name
  location            = local.location
  service_plan_id     = azurerm_service_plan.main.id
  https_only          = true

  identity {
    type = "SystemAssigned"
  }

  site_config {
    always_on = var.app_service_sku != "B1"
    application_stack {
      docker_registry_url = "https://${local.container_server}"
      docker_image_name   = local.container_image
    }
    health_check_path = "/health"
  }

  app_settings = {
    FLASK_ENV                               = var.environment
    SECRET_KEY                              = local.flask_secret
    JWT_SECRET_KEY                          = local.jwt_secret
    WEBSITES_PORT                           = "5000"
    DATABASE_URL                            = local.postgres_conn_str
    DOCKER_ENABLE_CI                        = "true"
    APPLICATIONINSIGHTS_CONNECTION_STRING   = azurerm_application_insights.main.connection_string
    LOG_LEVEL                               = var.log_level
  }

  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# Deployment Slot (Staging)
# ---------------------------------------------------------------------------
resource "azurerm_linux_web_app_slot" "staging" {
  count          = var.enable_deployment_slot ? 1 : 0
  name           = "staging"
  app_service_id = azurerm_linux_web_app.main.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    always_on = var.app_service_sku != "B1"
    application_stack {
      docker_registry_url = "https://${local.container_server}"
      docker_image_name   = local.container_image
    }
    health_check_path = "/health"
  }

  app_settings = {
    FLASK_ENV                               = "staging"
    SECRET_KEY                              = local.flask_secret
    JWT_SECRET_KEY                          = local.jwt_secret
    WEBSITES_PORT                           = "5000"
    DATABASE_URL                            = local.postgres_conn_str
    APPLICATIONINSIGHTS_CONNECTION_STRING   = azurerm_application_insights.main.connection_string
  }
}
