# ---------------------------------------------------------------------------
# General
# ---------------------------------------------------------------------------
variable "project_name" {
  description = "Project name used for resource naming"
  type        = string
  default     = "aircraft-maintenance"
}

variable "environment" {
  description = "Deployment environment (development, staging, production)"
  type        = string
  default     = "development"

  validation {
    condition     = contains(["development", "staging", "production"], var.environment)
    error_message = "Environment must be development, staging, or production."
  }
}

variable "location" {
  description = "Azure region for all resources"
  type        = string
  default     = "eastus"
}

variable "resource_group_name" {
  description = "Existing resource group name (leave empty to create new)"
  type        = string
  default     = ""
}

# ---------------------------------------------------------------------------
# Container Registry
# ---------------------------------------------------------------------------
variable "acr_sku" {
  description = "Azure Container Registry SKU (Basic, Standard, Premium)"
  type        = string
  default     = "Basic"
}

# ---------------------------------------------------------------------------
# App Service
# ---------------------------------------------------------------------------
variable "app_service_sku" {
  description = "App Service Plan SKU (B1, S1, P1v2, etc.)"
  type        = string
  default     = "B1"
}

variable "app_service_sku_tier" {
  description = "App Service Plan tier"
  type        = string
  default     = "Basic"
}

variable "app_instance_count" {
  description = "Number of App Service instances (1 for Basic, 1-10 for Standard+)"
  type        = number
  default     = 1
}

# ---------------------------------------------------------------------------
# PostgreSQL
# ---------------------------------------------------------------------------
variable "postgres_sku_name" {
  description = "PostgreSQL Flexible Server SKU (e.g., B_Standard_B1ms, GP_Standard_D2s_v3)"
  type        = string
  default     = "B_Standard_B1ms"
}

variable "postgres_storage_mb" {
  description = "PostgreSQL storage in MB"
  type        = number
  default     = 32768
}

variable "postgres_version" {
  description = "PostgreSQL version"
  type        = string
  default     = "16"
}

variable "postgres_admin_login" {
  description = "PostgreSQL admin login"
  type        = string
  default     = "psqladmin"
  sensitive   = true
}

variable "postgres_admin_password" {
  description = "PostgreSQL admin password (generate if empty)"
  type        = string
  default     = ""
  sensitive   = true
}

variable "postgres_database_name" {
  description = "PostgreSQL database name"
  type        = string
  default     = "aircraft_maintenance"
}

# ---------------------------------------------------------------------------
# Key Vault
# ---------------------------------------------------------------------------
variable "key_vault_sku" {
  description = "Key Vault SKU (standard, premium)"
  type        = string
  default     = "standard"
}

# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------
variable "flask_secret_key" {
  description = "Flask secret key (generate if empty)"
  type        = string
  default     = ""
  sensitive   = true
}

variable "jwt_secret_key" {
  description = "JWT secret key (generate if empty)"
  type        = string
  default     = ""
  sensitive   = true
}

variable "log_level" {
  description = "Application log level"
  type        = string
  default     = "info"
}

variable "docker_image_tag" {
  description = "Docker image tag to deploy"
  type        = string
  default     = "latest"
}

variable "enable_deployment_slot" {
  description = "Enable staging deployment slot for blue-green deployments"
  type        = bool
  default     = false
}
