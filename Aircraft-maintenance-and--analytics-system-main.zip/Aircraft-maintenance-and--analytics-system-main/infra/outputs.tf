# ---------------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------------

output "resource_group_name" {
  description = "Resource group name"
  value       = local.resource_group_name
}

output "app_service_url" {
  description = "App Service URL"
  value       = "https://${azurerm_linux_web_app.main.default_hostname}"
}

output "app_service_name" {
  description = "App Service name"
  value       = azurerm_linux_web_app.main.name
}

output "acr_login_server" {
  description = "Azure Container Registry login server"
  value       = azurerm_container_registry.main.login_server
}

output "acr_name" {
  description = "Azure Container Registry name"
  value       = azurerm_container_registry.main.name
}

output "postgres_fqdn" {
  description = "PostgreSQL server fully qualified domain name"
  value       = azurerm_postgresql_flexible_server.main.fqdn
  sensitive   = true
}

output "postgres_database_name" {
  description = "PostgreSQL database name"
  value       = azurerm_postgresql_flexible_server_database.main.name
}

output "key_vault_uri" {
  description = "Azure Key Vault URI"
  value       = azurerm_key_vault.main.vault_uri
}

output "application_insights_key" {
  description = "Application Insights instrumentation key"
  value       = azurerm_application_insights.main.instrumentation_key
  sensitive   = true
}

output "docker_build_command" {
  description = "Command to build and push Docker image"
  value       = "az acr build --registry ${azurerm_container_registry.main.name} --image ${var.project_name}:${var.docker_image_tag} ."
}

output "deploy_command" {
  description = "Command to trigger deployment"
  value       = "az webapp deploy --resource-group ${local.resource_group_name} --name ${azurerm_linux_web_app.main.name} --image ${azurerm_container_registry.main.name}.azurecr.io/${var.project_name}:${var.docker_image_tag} --type=Container"
}
