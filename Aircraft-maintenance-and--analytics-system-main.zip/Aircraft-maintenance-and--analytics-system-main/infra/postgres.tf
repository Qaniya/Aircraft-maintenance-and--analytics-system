# ---------------------------------------------------------------------------
# Azure Database for PostgreSQL Flexible Server
# ---------------------------------------------------------------------------
resource "random_password" "postgres" {
  length           = 32
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

resource "azurerm_postgresql_flexible_server" "main" {
  name                   = "psql-${var.project_name}-${var.environment}"
  resource_group_name    = local.resource_group_name
  location               = local.location
  version                = var.postgres_version
  administrator_login    = var.postgres_admin_login
  administrator_password = local.postgres_password
  storage_mb             = var.postgres_storage_mb
  sku_name               = var.postgres_sku_name
  zone                   = "1"

  backup_retention_days        = var.environment == "production" ? 14 : 7
  geo_redundant_backup_enabled = var.environment == "production"
  auto_grow_enabled            = true



  tags = local.common_tags
}

# ---------------------------------------------------------------------------
# PostgreSQL Firewall Rules
# ---------------------------------------------------------------------------
resource "azurerm_postgresql_flexible_server_firewall_rule" "azure_services" {
  name             = "allow-azure-services"
  server_id        = azurerm_postgresql_flexible_server.main.id
  start_ip_address = "0.0.0.0"
  end_ip_address   = "0.0.0.0"
}

resource "azurerm_postgresql_flexible_server_firewall_rule" "dev_all" {
  count            = var.environment == "production" ? 0 : 1
  name             = "allow-dev-all"
  server_id        = azurerm_postgresql_flexible_server.main.id
  start_ip_address = "0.0.0.0"
  end_ip_address   = "255.255.255.255"
}

# ---------------------------------------------------------------------------
# PostgreSQL Database
# ---------------------------------------------------------------------------
resource "azurerm_postgresql_flexible_server_database" "main" {
  name      = var.postgres_database_name
  server_id = azurerm_postgresql_flexible_server.main.id
  collation = "en_US.utf8"
  charset   = "utf8"
}
