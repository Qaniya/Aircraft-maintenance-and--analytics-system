terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"
    }
  }

  # Remote state storage - uncomment for production
  # backend "azurerm" {
  #   resource_group_name  = "rg-terraform-state"
  #   storage_account_name = "stterraformstateaircraft"
  #   container_name       = "tfstate"
  #   key                  = "aircraft-maintenance.tfstate"
  # }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = var.environment != "production"
    }

    postgresql_flexible_server {
    }
  }
}

# ---------------------------------------------------------------------------
# Data sources
# ---------------------------------------------------------------------------
data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "existing" {
  count = var.resource_group_name != "" ? 1 : 0
  name  = var.resource_group_name
}

# ---------------------------------------------------------------------------
# Resource Group
# ---------------------------------------------------------------------------
resource "azurerm_resource_group" "main" {
  count    = var.resource_group_name == "" ? 1 : 0
  name     = "rg-${var.project_name}-${var.environment}"
  location = var.location
  tags = {
    project     = var.project_name
    environment = var.environment
    managed_by  = "terraform"
  }
}

locals {
  resource_group_name = var.resource_group_name != "" ? var.resource_group_name : azurerm_resource_group.main[0].name
  location            = var.resource_group_name != "" ? data.azurerm_resource_group.existing[0].location : azurerm_resource_group.main[0].location
  common_tags = {
    project     = var.project_name
    environment = var.environment
    managed_by  = "terraform"
  }
  flask_secret       = var.flask_secret_key != "" ? var.flask_secret_key : random_password.flask[0].result
  jwt_secret         = var.jwt_secret_key != "" ? var.jwt_secret_key : random_password.jwt[0].result
  postgres_password  = var.postgres_admin_password != "" ? var.postgres_admin_password : random_password.postgres.result
  container_image    = "${azurerm_container_registry.main.name}/${var.project_name}:${var.docker_image_tag}"
  container_server   = azurerm_container_registry.main.login_server
  postgres_fqdn      = azurerm_postgresql_flexible_server.main.fqdn
  postgres_conn_str  = "postgresql://${var.postgres_admin_login}:${local.postgres_password}@${azurerm_postgresql_flexible_server.main.fqdn}:5432/${var.postgres_database_name}?sslmode=require"
}
